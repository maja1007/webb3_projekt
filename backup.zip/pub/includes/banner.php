<div class="banner">
	<img class="img-responsive" src="images/banner.jpg" alt="man writing on whiteboard" />
	<div class="container">
		<div class="text">
			<div class="heading">Roslagsmentorer</div>
			<div class="bannertext">En Roslagsmentor vill aktivt bidra till näringslivets utveckling inom kommunen.<br>
				 Vi ger, råd, stöd och operativ hjälp till lokala företagare</div>
		</div>
	</div>
</div><!--End Banner-->