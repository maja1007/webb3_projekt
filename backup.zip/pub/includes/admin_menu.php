 <!--Nav-->
 <nav id="main-nav">
      <div class="nav-container">
          <div class="topnav" id="myTopnav">
            <div class="logo">Logo</div>
            <ul>
              <a href="home.php" class="active"><i class="fas fa-home"> Admin Area</i></a>
              <a href="home.php"><i class="fas fa-pencil-alt"> Skriv inlägg </i></a>
              <a href="home.php"><i class="fas fa-plus-square"> Lägg till Menotor </i></a>
              <a href="logout.php"><i class="fas fa-sign-out-alt"> Logga ut </i></a>
              <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                <i class="fa fa-bars"></i>
              </a>
            </ul>
          </div>
      </div>
    </nav>    