<?php
//********************* */ 

// Skapad av:
// Martina Jansson
// Datum: 2018-10-28
// Student Mittuniversitetet, Kurs: DT173G

// **************************/
?>
 <!--Nav-->
 <nav id="main-nav">
      <div class="nav-container">
          <div class="topnav" id="myTopnav">
            <div class="logo">logo</div>
            <ul>
              <a href="index.php">Start</a>
              <a href="#intro-omoss">Om oss</a>
              <a href="#intro-mentorer">Våra mentorer</a>
              <a href="#intro-login">Login</a>
              <a href="#intro-contact">Kontakt</a>
              <a href="javascript:void(0);" class="icon" onclick="myFunction()">
              <i class="fa fa-bars"></i>
              </a>
            </ul>
          </div>
      </div>  
    </nav>     