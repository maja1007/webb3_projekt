     <footer>
     <h2>Footer</h2>
     </footer>
     <script src="js/main.min.js"></script>

      <!-- jQuery -->
      <script
      src="https://code.jquery.com/jquery-2.2.4.min.js"
      integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
      crossorigin="anonymous"></script>

      <!-- Font Awesome -->
  </body>
</html>