<?php
//********************* */ 

// Skapad av:
// Martina Jansson
// Datum: 2018-10-28
// Student Mittuniversitetet, Kurs: DT173G

// **************************/
?>
<?php include("config.php");?>
<?php include("includes/header.php");?>

<body>
<!-- Header
====================== -->
<header>
  <?php include('includes/mainmenu.php'); ?> 
</header> 
<!-- Main
====================== -->

<div class="container">
    <section>
        <article>
            <h2>Ops...Någonting gick fel</h2>
            <a href="index.php#intro-login">Gå tillbaka</a>
        </article>
    </section>
</div>

    <!-- Footer
  ====================== -->
<?php include("includes/footer.php");?>
